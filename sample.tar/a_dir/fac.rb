#!/usr/bin/env ruby

def fac(n)
  return 1 if n < 1
  1.upto(n).reduce(:*)
end

p fac 10
